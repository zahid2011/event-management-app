package com.example.event_lottery;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.event_lottery.R;

public class PastEventsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chosen_entrants_screen);
        // Retrieve and display past events here
    }
}
